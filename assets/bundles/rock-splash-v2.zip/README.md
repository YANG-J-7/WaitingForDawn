# 临山撞岩水花

2026-11-17，依据用户截图与generate2dsprite要求，使用内置image_gen生成独立六阶段水花。原稿1774×887，实际布局为3列2行；处理器严格QC通过，无空帧、触边或裁切。处理后单帧384方形，统一缩放/底线；水膜品红残色经冷蓝投色清除，alpha保持。源提示词见prompt-used.txt，原稿不覆盖。

正式地图通过level_beach_layer.gd加载六处临岩样点；五处东侧、一处南侧蓝岩，原点从当前山体alpha查询。西侧草坡两点经实景剔除。海浪沿岸相位轻微错开，撞岩水花按4秒周期、2.6秒有效动作、不同相位播放；六关键帧采用连续时间/预乘B样条过渡，非逐水滴流体模拟。主图统一暂停/恢复/重开，小地图只保留静态沙滩，不创建水花。

rock_contact.gdshaderinc在世界坐标采样山体alpha；沙/浪/水花共用水侧裁切，半透明边缘保守扩两世界单位，避免白线透进岩石。山体原画、坐标、2703水格与九梯不变。当前山体位置使用正式布局3528,-108、2倍；移动山体时须同步绑定矩形并重建样点。

重建：先运行generate2dsprite的process（2行3列、384单元、shared-scale、bottom、all、strict-qc），再运行tools/build_rock_splash.py；其仅去残色、导出GIF/元数据和查询布点。animation.gif为六关键帧预览；运行中B样条过渡更平滑。实际GL视频与验证由tests/test_rock_splash_gl.gd生成到本机tests/reports/images/rock-splash/。

最终视觉与近景贴合仍需结合实景复核，长局性能未验证；Story-033保持开放。
